<?php

class Cornerstone_Bar_Entity extends Cornerstone_Regions_Entity {

  public function get_library_scope( $settings ) {
    return 'bars';
  }
}
